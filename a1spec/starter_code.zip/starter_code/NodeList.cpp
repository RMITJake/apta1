#include "NodeList.h"
#include <iostream>

NodeList::NodeList(){
    // TODO
}

NodeList::~NodeList(){
    // TODO
}

NodeList::NodeList(NodeList& other){
    // TODO
}

int NodeList::getLength(){
    // TODO
}

void NodeList::addElement(Node* newPos){
    // TODO
}

Node* NodeList::getNode(int i){
    // TODO
}