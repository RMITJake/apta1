#include "Node.h"
#include <iostream>


Node::Node(int row, int col, int dist_traveled)
{
    // TODO
}

Node::~Node(){
    // TODO
}

int Node::getRow(){
    // TODO
}

int Node::getCol(){
    // TODO
}

int Node::getDistanceTraveled(){
    // TODO
}

void Node::setDistanceTraveled(int dist_traveled)
{
    // TODO
}

int Node::getEstimatedDist2Goal(Node* goal){
    // TODO
}
    
//--------------------------------                             